param(
    [string]$TargetDir = "$env:USERPROFILE\Documents\ArcGIS\AddIns\ArcGISPro"
)

$ErrorActionPreference = 'Stop'

$destination = Join-Path $TargetDir 'GoogleStreetView.esriAddinX'
if (Test-Path $destination) {
    Remove-Item $destination -Force
    Write-Host "Removed Google Street View add-in from: $destination"
} else {
    Write-Host "Add-in not found at: $destination"
}

Write-Host 'Restart ArcGIS Pro if it is currently open.'
