param(
    [string]$TargetDir = "$env:USERPROFILE\Documents\ArcGIS\AddIns\ArcGISPro"
)

$ErrorActionPreference = 'Stop'

$source = Join-Path $PSScriptRoot 'GoogleStreetView.esriAddinX'
if (-not (Test-Path $source)) {
    throw "Add-in package not found: $source"
}

New-Item -ItemType Directory -Force -Path $TargetDir | Out-Null
$destination = Join-Path $TargetDir 'GoogleStreetView.esriAddinX'
Copy-Item $source $destination -Force

Write-Host "Installed Google Street View add-in to: $destination"
Write-Host 'Restart ArcGIS Pro if it is currently open.'
