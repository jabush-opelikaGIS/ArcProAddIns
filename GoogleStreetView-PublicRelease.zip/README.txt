Google Street View for ArcGIS Pro

This package includes:
- GoogleStreetView.esriAddinX
- Install-GoogleStreetViewAddin.ps1
- Uninstall-GoogleStreetViewAddin.ps1
- README.txt

Installation:
1. Extract the zip.
2. Run Install-GoogleStreetViewAddin.ps1
3. Start or restart ArcGIS Pro.

Manual installation:
- Copy GoogleStreetView.esriAddinX to:
  %USERPROFILE%\Documents\ArcGIS\AddIns\ArcGISPro

Usage:
- Open ArcGIS Pro and activate a map view.
- On the Google Street View tab, click Open Street View.
- Click the map to open Google Street View in your default browser.

Notes:
- Street View availability depends on Google coverage.
- This add-in opens Google Street View in your browser and does not embed Google imagery inside ArcGIS Pro.
- Use of Google Street View is subject to Google's terms and licensing.

Credits:
James Bush
